def strrev(arg):
    return arg[::-1]

#s='pooja'
#print(strrev(s))