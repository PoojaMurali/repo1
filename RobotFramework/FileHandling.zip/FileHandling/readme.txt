1) Read CSV(import_user_sample_file.csv) file and write all the lines in another file (csv)


2)  a) Read sample.Csv and write the output into a separate file (txt file)
       Output file looks like:
       suresh
       dravid
       msdhoni
       kishore

    b) Read sample.csv file (read each line and append all the lines into a single list)
       print the list
       [['s','u','r','e','s','h'], ['d','r','a','v','i','d']....] Same for other lines also
  
    c) Read sample.CSV file (read each line and append all the lines into a single list)
       print the output list
       ['suresh', dravid, msdhoni....] Same for other lines also


3) Read sum_operations.csv file and write the sum of the  value in another file(txt file)
   output file looks like.
   115
   229
   Alpha characters present. sum operation cannot be performed.
   34
   Alpha numeric characters present. sum operation cannot be performed.
   