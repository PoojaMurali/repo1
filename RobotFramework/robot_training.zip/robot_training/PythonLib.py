class PythonLib:
    def output_print(self):
        print("Executing python library function")

    def output_print_passing_argument(self, message):
        print(message)