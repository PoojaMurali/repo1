def message():
    print("HeELLO")

def message_argument(arg1):
    print(arg1)

def sum(a,b):
    print(type(a))
    print(type(b))
    return int(a)+int(b)