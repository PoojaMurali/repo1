import sys

print("Command line args", sys.argv)
