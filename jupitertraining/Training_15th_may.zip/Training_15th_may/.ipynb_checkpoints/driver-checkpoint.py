import math


x = math.arithmatic.add(10,20)
print("Addition : ", x)

y = math.arithmatic.mul(10, 20)
print("Multiplication :", y)