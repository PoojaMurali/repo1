def add(a,b):
    return a + b
def mul(x,y):
    return x * y